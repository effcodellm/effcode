#!/usr/bin/env python3

import argparse
import json
from pathlib import Path

import torch
from datasets import Dataset
from peft import LoraConfig
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    set_seed,
)
from trl import SFTConfig, SFTTrainer


# ============================================================
# FINAL EFFCODE SFT TRAINING
# ============================================================

BASE_MODEL = "deepseek-ai/deepseek-coder-1.3b-instruct"

SEED = 42

EPOCHS = 1.0
LEARNING_RATE = 2e-4

BATCH_SIZE = 1
GRADIENT_ACCUMULATION = 8

MAX_LENGTH = 1536

LORA_R = 16
LORA_ALPHA = 32
LORA_DROPOUT = 0.05


def load_jsonl(path):
    if not path.exists():
        raise FileNotFoundError(
            f"File not found: {path}"
        )

    rows = []

    with open(
        path,
        "r",
        encoding="utf-8",
    ) as f:

        for line_number, line in enumerate(
            f,
            start=1,
        ):

            if not line.strip():
                continue

            row = json.loads(line)

            if "prompt" not in row:
                raise RuntimeError(
                    f"{path}:{line_number} "
                    "missing prompt"
                )

            if "completion" not in row:
                raise RuntimeError(
                    f"{path}:{line_number} "
                    "missing completion"
                )

            if not str(row["prompt"]).strip():
                raise RuntimeError(
                    f"{path}:{line_number} "
                    "empty prompt"
                )

            if not str(row["completion"]).strip():
                raise RuntimeError(
                    f"{path}:{line_number} "
                    "empty completion"
                )

            rows.append(row)

    if not rows:
        raise RuntimeError(
            f"No examples found in {path}"
        )

    return rows


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--data_dir",
        default="./effcode_sft_full",
    )

    parser.add_argument(
        "--output_dir",
        default="./sft_checkpoints_final",
    )

    parser.add_argument(
        "--base_model",
        default=BASE_MODEL,
    )

    args = parser.parse_args()

    set_seed(SEED)

    data_dir = Path(
        args.data_dir
    )

    if not (
        data_dir / "READY.txt"
    ).exists():

        raise RuntimeError(
            "READY.txt not found. "
            "Run preprocessing successfully first."
        )

    train_rows = load_jsonl(
        data_dir / "train.jsonl"
    )

    val_rows = load_jsonl(
        data_dir / "val.jsonl"
    )

    print(
        f"[data] train={len(train_rows)} "
        f"val={len(val_rows)}"
    )

    # --------------------------------------------------------
    # Build text datasets.
    # --------------------------------------------------------

    train_dataset = Dataset.from_list(
        [
            {
                "text":
                    row["prompt"]
                    + row["completion"]
            }
            for row in train_rows
        ]
    )

    val_dataset = Dataset.from_list(
        [
            {
                "text":
                    row["prompt"]
                    + row["completion"]
            }
            for row in val_rows
        ]
    )

    # --------------------------------------------------------
    # Tokenizer.
    # --------------------------------------------------------

    print(
        "[model] Loading tokenizer..."
    )

    tokenizer = AutoTokenizer.from_pretrained(
        args.base_model,
        trust_remote_code=True,
    )

    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # --------------------------------------------------------
    # Model.
    # --------------------------------------------------------

    print(
        "[model] Loading model..."
    )

    if torch.cuda.is_available():

        dtype = torch.float16

        print(
            "[GPU]",
            torch.cuda.get_device_name(0)
        )

        print(
            "[dtype] float16"
        )

    else:

        dtype = torch.float32

        print(
            "[GPU] CUDA unavailable"
        )

        print(
            "[dtype] float32"
        )

    model = AutoModelForCausalLM.from_pretrained(
        args.base_model,
        dtype=dtype,
        trust_remote_code=True,
    )

    # --------------------------------------------------------
    # LoRA.
    # --------------------------------------------------------

    lora_config = LoraConfig(
        r=LORA_R,
        lora_alpha=LORA_ALPHA,
        lora_dropout=LORA_DROPOUT,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=[
            "q_proj",
            "k_proj",
            "v_proj",
            "o_proj",
            "gate_proj",
            "up_proj",
            "down_proj",
        ],
    )

    # --------------------------------------------------------
    # Preflight.
    # --------------------------------------------------------

    for index in range(
        min(3, len(train_dataset))
    ):

        text = train_dataset[
            index
        ]["text"]

        if "### Response:" not in text:
            raise RuntimeError(
                f"Response marker missing "
                f"from training example {index}"
            )

        tokens = tokenizer(
            text,
            add_special_tokens=True,
            truncation=True,
            max_length=MAX_LENGTH,
        )

        if not tokens["input_ids"]:
            raise RuntimeError(
                f"Example {index} produced "
                "zero tokens"
            )

    print(
        "[preflight] OK"
    )

    # --------------------------------------------------------
    # SFT configuration.
    # --------------------------------------------------------

    training_args = SFTConfig(

        output_dir=args.output_dir,

        num_train_epochs=EPOCHS,

        per_device_train_batch_size=BATCH_SIZE,

        per_device_eval_batch_size=BATCH_SIZE,

        gradient_accumulation_steps=
            GRADIENT_ACCUMULATION,

        learning_rate=LEARNING_RATE,

        weight_decay=0.01,

        warmup_ratio=0.05,

        lr_scheduler_type="cosine",

        logging_steps=10,

        eval_strategy="epoch",

        save_strategy="epoch",

        save_total_limit=2,

        load_best_model_at_end=True,

        metric_for_best_model="eval_loss",

        greater_is_better=False,

        fp16=(
            dtype == torch.float16
        ),

        bf16=False,

        gradient_checkpointing=True,

        report_to=["none"],

        seed=SEED,

        dataset_text_field="text",

        max_length=MAX_LENGTH,

        packing=False,

        completion_only_loss=True,

        remove_unused_columns=False,

        optim="adamw_torch",
    )

    # --------------------------------------------------------
    # Trainer.
    # --------------------------------------------------------

    trainer = SFTTrainer(

        model=model,

        args=training_args,

        train_dataset=train_dataset,

        eval_dataset=val_dataset,

        processing_class=tokenizer,

        peft_config=lora_config,
    )

    print()
    print("=" * 60)
    print("STARTING FINAL SFT TRAINING")
    print("=" * 60)

    trainer.train()

    # --------------------------------------------------------
    # Save final adapter.
    # --------------------------------------------------------

    final_dir = (
        Path(args.output_dir)
        / "final"
    )

    final_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    trainer.save_model(
        str(final_dir)
    )

    tokenizer.save_pretrained(
        str(final_dir)
    )

    with open(
        final_dir / "training_info.json",
        "w",
        encoding="utf-8",
    ) as f:

        json.dump(
            {
                "base_model":
                    args.base_model,
                "train_examples":
                    len(train_rows),
                "validation_examples":
                    len(val_rows),
                "epochs": EPOCHS,
                "learning_rate":
                    LEARNING_RATE,
                "batch_size":
                    BATCH_SIZE,
                "gradient_accumulation":
                    GRADIENT_ACCUMULATION,
                "max_length":
                    MAX_LENGTH,
                "lora_r": LORA_R,
                "lora_alpha": LORA_ALPHA,
                "lora_dropout":
                    LORA_DROPOUT,
                "seed": SEED,
            },
            f,
            indent=2,
        )

    print()
    print("=" * 60)
    print("FINAL SFT TRAINING COMPLETE")
    print("=" * 60)

    print(
        f"[save] final adapter: "
        f"{final_dir}"
    )


if __name__ == "__main__":
    main()
