#!/usr/bin/env python3

import argparse
import json
import os
import re
import statistics
import subprocess
import sys
import time
from pathlib import Path

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer


BASE_MODEL = "deepseek-ai/deepseek-coder-1.3b-instruct"

NUM_SAMPLES = 5
TEMPERATURE = 0.8
TOP_P = 0.95
MAX_NEW_TOKENS = 1024
TIMEOUT = 5
MAX_TESTS = 5
K_VALUES = [1, 3, 5]

PROMPT_TEMPLATE = """### Instruction:
Write a correct and efficient Python program that solves the following problem. Read input from standard input and write output to standard output.

### Problem:
{question}

### Response:
"""


def parse_args():
    parser = argparse.ArgumentParser(
        description="EffCode pass@k and eff@k evaluation"
    )

    parser.add_argument(
        "--data_dir",
        default="./effcode_sft_full",
    )

    parser.add_argument(
        "--model_dir",
        required=True,
        help="Path to trained LoRA adapter",
    )

    parser.add_argument(
        "--base_model",
        default=BASE_MODEL,
    )

    parser.add_argument(
        "--output",
        default="./evaluation_results.json",
    )

    return parser.parse_args()


def fail(message):
    raise RuntimeError(message)


def load_evaluation_data(path):

    if not path.exists():
        fail(f"Evaluation file not found: {path}")

    rows = []

    with path.open(
        "r",
        encoding="utf-8",
    ) as file:

        for line_number, line in enumerate(
            file,
            start=1,
        ):

            if not line.strip():
                continue

            try:
                row = json.loads(line)

            except json.JSONDecodeError as error:
                fail(
                    f"Invalid JSON at line "
                    f"{line_number}: {error}"
                )

            for field in [
                "id",
                "question",
                "input_output",
                "reference_solutions",
            ]:

                if field not in row:
                    fail(
                        f"Line {line_number} "
                        f"missing {field}"
                    )

            io = row["input_output"]

            if not isinstance(io, dict):
                fail(
                    f"Line {line_number}: "
                    "input_output is not an object"
                )

            inputs = io.get("inputs")
            outputs = io.get("outputs")

            if (
                not isinstance(inputs, list)
                or not isinstance(outputs, list)
                or not inputs
                or len(inputs) != len(outputs)
            ):
                fail(
                    f"Line {line_number}: "
                    "invalid test cases"
                )

            refs = row["reference_solutions"]

            if not isinstance(refs, list) or not refs:
                fail(
                    f"Line {line_number}: "
                    "reference_solutions is empty"
                )

            row["_refs"] = [
                str(x)
                for x in refs
                if str(x).strip()
            ]

            rows.append(row)

    if not rows:
        fail("eval.jsonl is empty")

    return rows


def extract_code(text):

    text = text.strip()

    match = re.search(
        r"```(?:python|py)?\s*(.*?)```",
        text,
        flags=re.DOTALL | re.IGNORECASE,
    )

    if match:
        return match.group(1).strip()

    return text


def static_check(code):

    if not code.strip():
        return False

    try:
        compile(
            code,
            "<generated>",
            "exec",
        )
    except Exception:
        return False

    banned = [
        r"\bos\.system\s*\(",
        r"\bos\.popen\s*\(",
        r"\bsubprocess\.",
        r"\bsocket\.",
        r"\brequests\.",
        r"\burllib\.",
        r"\bshutil\.rmtree\s*\(",
        r"\b__import__\s*\(",
    ]

    return not any(
        re.search(pattern, code)
        for pattern in banned
    )


def run_program(
    code,
    input_data,
    timeout,
):

    if not static_check(code):
        return False, float("inf"), ""

    start = time.perf_counter()

    try:
        process = subprocess.run(
            [
                sys.executable,
                "-I",
                "-c",
                code,
            ],
            input=str(input_data),
            text=True,
            capture_output=True,
            timeout=timeout,
        )

    except (
        subprocess.TimeoutExpired,
        OSError,
    ):
        return False, float("inf"), ""

    elapsed = (
        time.perf_counter() - start
    )

    if process.returncode != 0:
        return False, elapsed, ""

    return (
        True,
        elapsed,
        process.stdout,
    )


def check_solution(
    code,
    input_output,
):

    inputs = input_output["inputs"][
        :MAX_TESTS
    ]

    outputs = input_output["outputs"][
        :MAX_TESTS
    ]

    total_runtime = 0.0

    for inp, expected in zip(
        inputs,
        outputs,
    ):

        ok, runtime, actual = run_program(
            code,
            inp,
            TIMEOUT,
        )

        if not ok:
            return False, float("inf")

        if actual.strip() != str(
            expected
        ).strip():

            return False, float("inf")

        total_runtime += runtime

    return True, total_runtime


def generate_solutions(
    model,
    tokenizer,
    question,
    num_samples,
):

    prompt = PROMPT_TEMPLATE.format(
        question=question.strip()
    )

    tokens = tokenizer(
        prompt,
        return_tensors="pt",
    )

    device = next(
        model.parameters()
    ).device

    tokens = {
        key: value.to(device)
        for key, value in tokens.items()
    }

    solutions = []

    for _ in range(num_samples):

        with torch.no_grad():

            output = model.generate(
                **tokens,
                max_new_tokens=MAX_NEW_TOKENS,
                do_sample=True,
                temperature=TEMPERATURE,
                top_p=TOP_P,
                pad_token_id=
                    tokenizer.pad_token_id,
                eos_token_id=
                    tokenizer.eos_token_id,
            )

        input_length = (
            tokens["input_ids"].shape[1]
        )

        generated = output[
            0,
            input_length:
        ]

        text = tokenizer.decode(
            generated,
            skip_special_tokens=True,
        )

        solutions.append(
            extract_code(text)
        )

    return solutions


def main():

    args = parse_args()

    if not os.path.isdir(args.model_dir):
        fail(
            f"Adapter directory not found: "
            f"{args.model_dir}"
        )

    if not os.path.isfile(
        os.path.join(
            args.model_dir,
            "adapter_config.json",
        )
    ):
        fail(
            "adapter_config.json not found. "
            "The model_dir is not a LoRA adapter."
        )

    rows = load_evaluation_data(
        Path(args.data_dir)
        / "eval.jsonl"
    )

    print(
        f"[data] evaluation problems="
        f"{len(rows)}"
    )

    if torch.cuda.is_available():
        dtype = torch.float16
        device_map = "auto"

        print(
            "[GPU]",
            torch.cuda.get_device_name(0),
        )

    else:
        dtype = torch.float32
        device_map = None

        print("[GPU] CUDA unavailable")

    print("[model] Loading tokenizer...")

    tokenizer = AutoTokenizer.from_pretrained(
        args.base_model,
        trust_remote_code=True,
    )

    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    print("[model] Loading base model...")

    base_model = (
        AutoModelForCausalLM.from_pretrained(
            args.base_model,
            dtype=dtype,
            device_map=device_map,
            trust_remote_code=True,
        )
    )

    print("[model] Loading trained LoRA adapter...")

    model = PeftModel.from_pretrained(
        base_model,
        args.model_dir,
    )

    model.eval()

    print(
        "[model] Adapter loaded successfully."
    )

    pass_counts = {
        k: 0
        for k in K_VALUES
    }

    eff_counts = {
        k: 0
        for k in K_VALUES
    }

    details = []

    for index, row in enumerate(
        rows,
        start=1,
    ):

        print(
            f"[eval] {index}/{len(rows)} "
            f"id={row['id']}"
        )

        generated = generate_solutions(
            model,
            tokenizer,
            row["question"],
            NUM_SAMPLES,
        )

        model_pass = []
        model_runtime = []

        for solution in generated:

            passed, runtime = check_solution(
                solution,
                row["input_output"],
            )

            model_pass.append(passed)

            model_runtime.append(
                runtime if passed else None
            )

        reference_runtimes = []

        for reference in row["_refs"]:

            passed, runtime = check_solution(
                reference,
                row["input_output"],
            )

            if passed:
                reference_runtimes.append(
                    runtime
                )

        item = {
            "id": row["id"],
            "difficulty": row.get(
                "difficulty"
            ),
            "model_pass": model_pass,
            "model_runtimes": model_runtime,
            "reference_passing_runtimes":
                reference_runtimes,
        }

        for k in K_VALUES:

            passed = any(
                model_pass[:k]
            )

            effective = False

            if (
                passed
                and reference_runtimes
            ):

                passing_model_runtimes = [
                    model_runtime[i]
                    for i in range(k)
                    if model_pass[i]
                ]

                fastest_model = min(
                    passing_model_runtimes
                )

                average_reference = (
                    statistics.mean(
                        reference_runtimes
                    )
                )

                effective = (
                    fastest_model
                    < average_reference
                )

            if passed:
                pass_counts[k] += 1

            if effective:
                eff_counts[k] += 1

            item[
                f"pass@{k}"
            ] = passed

            item[
                f"eff@{k}"
            ] = effective

        details.append(item)

    n = len(rows)

    metrics = {}

    for k in K_VALUES:

        metrics[
            f"pass@{k}"
        ] = pass_counts[k] / n

        metrics[
            f"eff@{k}"
        ] = eff_counts[k] / n

    result = {
        "summary": {
            "num_problems": n,
            "num_samples": NUM_SAMPLES,
            "temperature": TEMPERATURE,
            "max_tests": MAX_TESTS,
            "metrics": metrics,
        },
        "problems": details,
    }

    output_path = Path(
        args.output
    )

    output_path.write_text(
        json.dumps(
            result,
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    print()
    print("=" * 60)
    print("EVALUATION COMPLETE")
    print("=" * 60)

    print(
        f"Problems : {n}"
    )

    for k in K_VALUES:

        print(
            f"pass@{k}: "
            f"{metrics[f'pass@{k}']:.4f}"
        )

        print(
            f"eff@{k}:  "
            f"{metrics[f'eff@{k}']:.4f}"
        )

    print(
        f"[save] Results saved to: "
        f"{output_path}"
    )


if __name__ == "__main__":
    main()
