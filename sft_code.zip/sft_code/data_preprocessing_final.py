#!/usr/bin/env python3

import argparse
import ast
import json
import random
import re
import shutil
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np
from huggingface_hub import hf_hub_download
from transformers import AutoTokenizer


# ============================================================
# FINAL EFFCODE APPS PREPROCESSING
# ============================================================

MODEL_NAME = "deepseek-ai/deepseek-coder-1.3b-instruct"

DIFFICULTIES = {
    "introductory",
    "interview",
    "competition",
}

MAX_CANDIDATES = 8
MAX_TESTS = 5
TIMEOUT_SECONDS = 5
MAX_LENGTH = 1536

VAL_FRACTION = 0.10
EVAL_FRACTION = 0.10
SEED = 42


def clean_text(value):
    if value is None:
        return ""
    text = str(value)
    text = text.replace("\ufeff", "")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return text.strip()


def clean_code(value):
    if value is None:
        return ""
    text = str(value)
    text = text.replace("\ufeff", "")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return text.expandtabs(4).strip()


def parse_json(value):
    if isinstance(value, (dict, list)):
        return value
    if not isinstance(value, str):
        return None
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return None


def static_check(code):
    if not code.strip():
        return False

    try:
        ast.parse(code)
    except (SyntaxError, ValueError, TypeError):
        return False

    banned = [
        r"\bos\.system\s*\(",
        r"\bos\.popen\s*\(",
        r"\bsubprocess\.",
        r"\bsocket\.",
        r"\brequests\.",
        r"\burllib\.",
        r"\bshutil\.rmtree\s*\(",
        r"\b__import__\s*\(",
    ]

    return not any(re.search(p, code) for p in banned)


def run_code(code, input_data):
    if not static_check(code):
        return False, ""

    try:
        result = subprocess.run(
            [sys.executable, "-I", "-c", code],
            input=str(input_data),
            text=True,
            capture_output=True,
            timeout=TIMEOUT_SECONDS,
        )
    except (subprocess.TimeoutExpired, OSError):
        return False, ""

    if result.returncode != 0:
        return False, ""

    return True, result.stdout


def verify_candidate(code, input_output):
    if not static_check(code):
        return False

    inputs = input_output["inputs"][:MAX_TESTS]
    outputs = input_output["outputs"][:MAX_TESTS]

    for inp, expected in zip(inputs, outputs):
        ok, actual = run_code(code, inp)

        if not ok:
            return False

        if actual.strip() != str(expected).strip():
            return False

    return True


def prepare_problem(row):
    if "question" not in row:
        return None

    if "solutions" not in row:
        return None

    if "input_output" not in row:
        return None

    difficulty = clean_text(row.get("difficulty")).lower()

    if difficulty not in DIFFICULTIES:
        return None

    question = clean_text(row["question"])
    solutions = parse_json(row["solutions"])
    input_output = parse_json(row["input_output"])

    if not question:
        return None

    if not isinstance(solutions, list):
        return None

    if not isinstance(input_output, dict):
        return None

    inputs = input_output.get("inputs")
    outputs = input_output.get("outputs")

    if not isinstance(inputs, list):
        return None

    if not isinstance(outputs, list):
        return None

    if not inputs or len(inputs) != len(outputs):
        return None

    cleaned_solutions = [
        clean_code(x)
        for x in solutions
        if clean_code(x)
    ]

    if not cleaned_solutions:
        return None

    return {
        "id": row.get("id"),
        "difficulty": difficulty,
        "question": question,
        "starter_code": clean_text(row.get("starter_code", "")),
        "solutions": cleaned_solutions,
        "input_output": {
            "inputs": inputs,
            "outputs": outputs,
        },
    }


def build_prompt(question, starter_code):
    prompt = (
        "### Instruction:\n"
        "Write a correct and efficient Python program that solves "
        "the following problem. Read input from standard input and "
        "write output to standard output.\n\n"
        "### Problem:\n"
        f"{question}\n"
    )

    if starter_code:
        prompt += (
            "\n### Starter Code:\n"
            f"{starter_code}\n"
        )

    prompt += "\n### Response:\n"
    return prompt


def select_verified_solution(problem):
    candidates = problem["solutions"][:MAX_CANDIDATES]

    for candidate in candidates:
        if verify_candidate(
            candidate,
            problem["input_output"],
        ):
            return candidate

    return None


def load_apps():
    print("[download] downloading APPS test.jsonl...")

    path = hf_hub_download(
        repo_id="codeparrot/apps",
        filename="test.jsonl",
        repo_type="dataset",
    )

    rows = []

    with open(
        path,
        "r",
        encoding="utf-8",
        errors="replace",
    ) as f:
        for line in f:
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    print(f"[download] loaded {len(rows)} APPS problems")

    if len(rows) != 5000:
        print(
            "[warning] Expected 5000 APPS test problems, "
            f"but loaded {len(rows)}."
        )

    return rows


def stratified_split(rows):
    rng = random.Random(SEED)

    groups = {}

    for row in rows:
        groups.setdefault(
            row["difficulty"], []
        ).append(row)

    train = []
    val = []
    evaluation = []

    for difficulty, group in groups.items():
        rng.shuffle(group)

        n = len(group)

        n_val = max(
            1,
            int(round(n * VAL_FRACTION)),
        )

        n_eval = max(
            1,
            int(round(n * EVAL_FRACTION)),
        )

        if n_val + n_eval >= n:
            n_val = max(1, n_val - 1)
            n_eval = max(1, n_eval - 1)

        evaluation.extend(group[:n_eval])

        val.extend(
            group[n_eval:n_eval + n_val]
        )

        train.extend(
            group[n_eval + n_val:]
        )

    rng.shuffle(train)
    rng.shuffle(val)
    rng.shuffle(evaluation)

    train_ids = {x["id"] for x in train}
    val_ids = {x["id"] for x in val}
    eval_ids = {x["id"] for x in evaluation}

    assert not train_ids & val_ids
    assert not train_ids & eval_ids
    assert not val_ids & eval_ids

    return train, val, evaluation


def write_jsonl(path, rows):
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(
                json.dumps(
                    row,
                    ensure_ascii=False,
                )
                + "\n"
            )


def verify_jsonl(path, expected_count, fields):
    count = 0

    with open(path, "r", encoding="utf-8") as f:
        for line_number, line in enumerate(f, 1):
            if not line.strip():
                continue

            row = json.loads(line)

            for field in fields:
                if field not in row:
                    raise RuntimeError(
                        f"{path}:{line_number} missing {field}"
                    )

            count += 1

    if count != expected_count:
        raise RuntimeError(
            f"{path}: expected {expected_count} rows, "
            f"found {count}"
        )


def save_dataset(train, val, evaluation, output_dir):
    output = Path(output_dir)

    if output.exists():
        if (output / "READY.txt").exists():
            raise RuntimeError(
                f"{output} is already a completed dataset. "
                "Use a new output directory."
            )
        shutil.rmtree(output)

    building = Path(
        str(output) + ".building"
    )

    if building.exists():
        shutil.rmtree(building)

    building.mkdir(parents=True)

    try:
        train_rows = [
            {
                "id": x["id"],
                "difficulty": x["difficulty"],
                "prompt": x["prompt"],
                "completion": x["completion"],
            }
            for x in train
        ]

        val_rows = [
            {
                "id": x["id"],
                "difficulty": x["difficulty"],
                "prompt": x["prompt"],
                "completion": x["completion"],
            }
            for x in val
        ]

        # Reference solutions are retained ONLY for evaluation.
        eval_rows = [
            {
                "id": x["id"],
                "difficulty": x["difficulty"],
                "question": x["question"],
                "starter_code": x["starter_code"],
                "input_output": x["input_output"],
                "reference_solutions": x["reference_solutions"],
            }
            for x in evaluation
        ]

        train_path = building / "train.jsonl"
        val_path = building / "val.jsonl"
        eval_path = building / "eval.jsonl"

        write_jsonl(train_path, train_rows)
        write_jsonl(val_path, val_rows)
        write_jsonl(eval_path, eval_rows)

        verify_jsonl(
            train_path,
            len(train_rows),
            ["id", "difficulty", "prompt", "completion"],
        )

        verify_jsonl(
            val_path,
            len(val_rows),
            ["id", "difficulty", "prompt", "completion"],
        )

        verify_jsonl(
            eval_path,
            len(eval_rows),
            [
                "id",
                "difficulty",
                "question",
                "input_output",
                "reference_solutions",
            ],
        )

        from datasets import Dataset, DatasetDict

        dataset = DatasetDict(
            {
                "train": Dataset.from_list(train_rows),
                "validation": Dataset.from_list(val_rows),
            }
        )

        dataset.save_to_disk(
            str(building / "hf_dataset")
        )

        stats = {
            "raw_apps_problems": 5000,
            "verified_examples": len(train) + len(val) + len(evaluation),
            "train": len(train),
            "validation": len(val),
            "evaluation": len(evaluation),
            "difficulties": sorted(DIFFICULTIES),
            "max_candidates": MAX_CANDIDATES,
            "max_tests": MAX_TESTS,
            "timeout_seconds": TIMEOUT_SECONDS,
            "max_length": MAX_LENGTH,
            "seed": SEED,
        }

        with open(
            building / "preprocessing_stats.json",
            "w",
            encoding="utf-8",
        ) as f:
            json.dump(stats, f, indent=2)

        with open(
            building / "READY.txt",
            "w",
            encoding="utf-8",
        ) as f:
            f.write(
                "FINAL EFFCODE DATASET READY\n"
            )

        building.rename(output)

    except Exception:
        if building.exists():
            shutil.rmtree(building)
        raise


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--output_dir",
        default="./effcode_sft_full",
    )

    args = parser.parse_args()

    print("=" * 60)
    print("EFFCODE FINAL APPS PREPROCESSING")
    print("=" * 60)

    raw = load_apps()

    # --------------------------------------------------------
    # Filter and validate all selected difficulties.
    # --------------------------------------------------------

    cleaned = []
    drops = Counter()

    for row in raw:
        difficulty = clean_text(
            row.get("difficulty")
        ).lower()

        if difficulty not in DIFFICULTIES:
            drops["other_difficulty"] += 1
            continue

        prepared = prepare_problem(row)

        if prepared is None:
            drops["invalid_problem"] += 1
            continue

        cleaned.append(prepared)

    print(
        f"[validate] kept {len(cleaned)}/{len(raw)}"
    )

    print(
        "[validate] drops:",
        dict(drops),
    )

    # --------------------------------------------------------
    # Deduplicate by ID.
    # --------------------------------------------------------

    unique = []
    seen = set()

    for row in cleaned:
        if row["id"] in seen:
            continue

        seen.add(row["id"])
        unique.append(row)

    print(
        f"[dedup] kept {len(unique)}/{len(cleaned)}"
    )

    # --------------------------------------------------------
    # Verify solutions.
    # --------------------------------------------------------

    verified = []
    no_solution = 0

    for index, problem in enumerate(
        unique,
        start=1,
    ):
        solution = select_verified_solution(
            problem
        )

        if solution is None:
            no_solution += 1
            continue

        verified.append(
            {
                "id": problem["id"],
                "difficulty": problem["difficulty"],
                "question": problem["question"],
                "starter_code": problem["starter_code"],
                "prompt": build_prompt(
                    problem["question"],
                    problem["starter_code"],
                ),
                "completion": solution,
                "input_output": problem["input_output"],
                "reference_solutions": problem["solutions"],
            }
        )

        if len(verified) % 200 == 0:
            print(
                f"[selection] verified examples="
                f"{len(verified)}"
            )

    print(
        f"[selection] verified={len(verified)}"
    )

    print(
        f"[selection] no verified solution="
        f"{no_solution}"
    )

    if not verified:
        raise RuntimeError(
            "No verified examples were produced."
        )

    # --------------------------------------------------------
    # Token-length filtering.
    # --------------------------------------------------------

    print(
        "[tokenizer] loading tokenizer..."
    )

    tokenizer = AutoTokenizer.from_pretrained(
        MODEL_NAME,
        trust_remote_code=True,
    )

    length_kept = []
    lengths = []

    for row in verified:
        text = (
            row["prompt"]
            + row["completion"]
        )

        token_count = len(
            tokenizer(
                text,
                add_special_tokens=True,
                truncation=False,
            )["input_ids"]
        )

        lengths.append(token_count)

        if token_count <= MAX_LENGTH:
            length_kept.append(row)

    print(
        f"[length] min={min(lengths)} "
        f"max={max(lengths)} "
        f"mean={np.mean(lengths):.1f}"
    )

    print(
        f"[length] kept={len(length_kept)}/"
        f"{len(verified)} "
        f"max_length={MAX_LENGTH}"
    )

    if not length_kept:
        raise RuntimeError(
            "No examples remain after length filtering."
        )

    # --------------------------------------------------------
    # Split.
    # --------------------------------------------------------

    train, val, evaluation = stratified_split(
        length_kept
    )

    print(
        f"[split] train={len(train)} "
        f"val={len(val)} "
        f"eval={len(evaluation)}"
    )

    # --------------------------------------------------------
    # Save.
    # --------------------------------------------------------

    save_dataset(
        train,
        val,
        evaluation,
        args.output_dir,
    )

    print()
    print("=" * 60)
    print("PREPROCESSING SUCCESSFUL")
    print("=" * 60)

    print(f"Train : {len(train)}")
    print(f"Val   : {len(val)}")
    print(f"Eval  : {len(evaluation)}")
    print(
        f"Total : "
        f"{len(train) + len(val) + len(evaluation)}"
    )
    print(
        f"Output: {args.output_dir}"
    )


if __name__ == "__main__":
    main()
